<?php

$tall = rand(1,100);

if($tall > 50) {
    echo "Tallet er over 50";
}  else {
    echo "Tallet er 50 eller mindre";
}

?>