<?php

$x = 0;

while($x <= 10) {
    echo "X<br>";

    $x = $x + 1;
}

echo "Y"

  

?>