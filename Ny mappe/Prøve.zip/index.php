<?php
include "variabler.php";

echo "<br>";

include "if.php";

echo "<br>";

include "ifløkke.php";

echo "<br>";

include "toløkker.php";

echo "<br>";

include "skjema.php";

echo "<br>";

include "mottaskjema.php";
?>