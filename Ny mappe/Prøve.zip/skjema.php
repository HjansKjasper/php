

<form action="mottaskjema.php" method="GET">
    Ditt Navn
    <input type="text" name="dittnavn">

    Inntekt 2020
    <input type="number" name="inntekt2020">

    Inntekt 2021
    <input type="number" name="inntekt2021">

    Inntekt 2022
    <input type="number" name="inntekt2022">

    <input type="submit" name="sendinn" value="Send inn">
</form>


