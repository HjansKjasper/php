<?php

$a = 0;
$b = 0;

while($a < 1) {
    echo "* <br>* *<br>* * *<br>";

    $a = $a + 1;
}

while($b < 1) {
    echo "* * * *<br>* * * * *";

    $b = $b + 1;
}

?>